import SimpleForm from '../js/simple-form.js';
window.SimpleForm = SimpleForm;